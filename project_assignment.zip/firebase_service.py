# Import the Firebase service
import firebase_admin
from firebase_admin import credentials, db

# Other Modules
import json

# Load appsettings JSON file
with open('appsettings.json', 'r') as json_file:
    appsettings = json.load(json_file)

# Firebase-APIKey File
API_KEY_PATH = "my-final-project-be3b9-firebase-adminsdk-37p8f-bc2c4e7c31.json" #Add your API file path

# Initialize the default firebase app
certificate = credentials.Certificate(API_KEY_PATH) 
firebaseApp = firebase_admin.initialize_app(certificate, {'databaseURL': appsettings['DatabaseURL']})



class ProductsCollection():

    def __init__(self):
        self.collection = db.reference(appsettings['ProductCollection'])
        self.key = appsettings['ProductCollectionUniqueKey']
    
    def __getSnapshot(self):
        return self.collection.get()
    
    def __findItem(self, id):
        snapshot = self.__getSnapshot()
        if snapshot == None:
            return False
        item = None
        for key, val in snapshot.items():
            if val[self.key] == id:
                item = key
                break
        if(item != None):
            node = self.collection.child(item)
            return node
        else:
            return False

    def addProductsItem(self, content):
        if self.key in content:
            if not self.__findItem(content[self.key]):
                self.collection.push(content)
                return True
            else:
                raise Exception("Item already exists")
        else:
            raise Exception("Key {0} not found".format(self.key))

    def getProductItems(self):
        snapshot = self.__getSnapshot()
        if snapshot == None:
            return []
        products = []
        for key, val in snapshot.items():
            products.append(val)
        return products

    def getProductItem(self,id):
        productList = self.getProductItems()
        products = next((item for item in productList if item[self.key] == id), None)
        return products

    def clearAllItems(self):
        self.collection.delete()
        return True

    def updateProductsItem(self, id, content):
        itemMatchedNode = self.__findItem(id)
        if(itemMatchedNode == False):
            raise Exception("Item doesn't exists")
        itemMatchedNode.set(content)
        return True

    def deleteProductsItem(self, id):
        itemMatchedNode = self.__findItem(id)
        if(itemMatchedNode == False):
            raise Exception("Item doesn't exists")
        itemMatchedNode.delete()
        return True