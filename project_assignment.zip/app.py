# Import Firebase Product Collection
from firebase_service import ProductsCollection

# Import Modules for FLASK
from flask import Flask, jsonify, request, render_template
from flask_restful import Api, Resource
from flask_cors import CORS, cross_origin


# Initialize Flask app
app = Flask(__name__)
CORS(app, support_credentials=True)
api = Api(app)

#index route
@app.route("/")
def index():
      return render_template("index.html")

class HealthCheck(Resource):
    @app.route('/api/health', methods=['GET'])
    @cross_origin(support_credentials=True)
    def checkHealth():
        """
            checkHealth(): Check whether the service is working or not
        """
        return "Healthy"


class ProductItemsList(Resource):
    @app.route('/api/getAllItems', methods=['GET'])
    @cross_origin(support_credentials=True)
    def getProductItems():

        try:
            productItems = productService.getProductItems()
            return jsonify(productItems)
        except Exception as ex:
            return str(ex), 400

class getProductItem(Resource):
    @app.route('/api/getItem', methods=['POST'])
    @cross_origin(support_credentials=True)
    def getItem():
        """
         Request Body ={"id": 1}
        """
        try:
            json_data = request.get_json(force=True)
            itemId = json_data['id']
            itemValue = productService.getProductItem(itemId)
            return jsonify(itemValue)
        except Exception as ex:
            return str(ex), 400

class AddProductsItem(Resource):
    @app.route('/api/addItem', methods=['POST'])
    @cross_origin(support_credentials=True)
    def addItem():
        """
            e.g. Request Body = {"id": 1 , "task": "My Produts"}
        """
        try:
            json_data = request.get_json(force=True)
            itemValue =productService.addProductsItem(json_data)
            return jsonify(itemValue)
        except Exception as ex:
            return str(ex), 400

class DeleteProductsItem(Resource):
    @app.route('/api/deleteItem', methods=['DELETE'])
    @cross_origin(support_credentials=True)
    def deleteItem():
        """
            e.g. Request Body = {"id": 1 }
        """
        try:
            json_data = request.get_json(force=True)
            itemId = json_data['id']
            status =productService.deleteProductsItem(itemId)
            return jsonify(status)
        except Exception as ex:
            return str(ex), 400

class DeleteAllProductsItems(Resource):
    @app.route('/api/deleteAllItems', methods=['DELETE'])
    @cross_origin(support_credentials=True)
    def deleteAll():
        try:
            status =productService.clearAllItems()
            return jsonify(status)
        except Exception as ex:
            return str(ex), 400

class UpdateProductsItem(Resource):
    @app.route('/api/updateItem', methods=['POST'])
    @cross_origin(support_credentials=True)
    def updateItem():
        """
            e.g. Request Body = {"id": 1, "task": "My updated task" }
        """
        try:
            json_data = request.get_json(force=True)
            itemId = json_data['id']
            status =productService.updateProductsItem(itemId, json_data)
            return jsonify(status)
        except Exception as ex:
            return str(ex), 400

if __name__ == "__main__":
    productService = ProductsCollection()
    app.run(debug=True) # Make sure debug is false on production environment